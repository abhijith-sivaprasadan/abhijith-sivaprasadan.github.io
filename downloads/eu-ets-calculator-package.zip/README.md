# Energy Cost + EU ETS Exposure Calculator (Excel + optional Python)

A **demo decision tool** to estimate:
- CO₂ emissions from electricity + fuels (Scope 1 / Scope 2 shown separately)
- **EU ETS cost exposure** for **direct (Scope 1)** emissions under EUA price scenarios (Low/Mid/High)
- Sensitivity outputs + simple “top levers” guidance

> Demo toolkit + workflow; replace assumptions (emission factors, conversions, prices) with site-approved values.

---

## Files
- `EU_ETS_Exposure_Calculator_Template.xlsx` — blank template (ready for your site data)
- `EU_ETS_Exposure_Calculator_Demo.xlsx` — same template with demo data filled in
- `demo_activity_data.csv` — demo activity data
- `EU_ETS_Exposure_Calculator_Notebook.ipynb` — optional notebook showing how to read outputs and recreate sensitivity plots

---

## How to use (Excel)
1) Go to **Inputs** and enter activity data by period:
   - Electricity (MWh)
   - Natural gas (Nm³ or MWh)
   - Other fuels (MWh), steam (MWh) if relevant
   - Optional: production (t), electricity price (€/MWh)

2) Go to **Factors** and set:
   - Emission factors (tCO₂/MWh)
   - Gas conversion (kWh per Nm³)
   - EUA price scenarios (€/tCO₂)

3) Choose an EUA scenario in **Inputs!B3** (Low/Mid/High)

4) View results in **Dashboard**
   - Total Scope 1 emissions (tCO₂)
   - ETS cost exposure (selected scenario + sensitivity table)
   - Charts: scenario bar chart, ETS cost over time, emissions breakdown

---

## Important scope note (EU ETS vs electricity)
- The **ETS cost** in this template applies to **direct (Scope 1) fuel combustion emissions**.
- Electricity-related emissions are shown as **Scope 2** for reporting/proxy comparisons.
  (Electricity ETS costs are typically embedded upstream in power prices, not paid as allowances by industrial consumers.)

If you want to treat electricity CO₂ as a **proxy carbon cost**, add a clear pass-through assumption.

---

## “Top 3 levers” (examples)
- Reduce fuel use (efficiency, maintenance, tuning, leak reduction)
- Heat recovery / steam optimization (waste heat, insulation, steam traps)
- Flexibility & markets (load shifting, peak reduction, demand response)
